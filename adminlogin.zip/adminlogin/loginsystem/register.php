<!DOCTYPE html>
<html lang="en">
<head>
	<title>Register</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
<?php  

if(isset($_POST["submit"])){  

    $eid=$_POST['eid'];  
	
    $username=$_POST['username'];
	$password=md5($_POST['password']);  
	$email=$_POST['email'];
		
    $phone=$_POST['phone'];	
    $con=mysqli_connect('localhost','root','mani1234') ;  
    mysqli_select_db($con,'loginsystem');  
  
    $query=mysqli_query($con,"SELECT * FROM loginsystem.user WHERE eid='".$eid."'");  
    $numrows=mysqli_num_rows($con,$query);  
    if($numrows==0)  
    {  
    $sql="INSERT INTO loginsystem.user(eid,username,password,rpassword,email,phone) VALUES('$eid','$username','$password','0','$email','$phone')";  
  
    $result=mysqli_query($con,$sql);  
        if($result){  
    ?>
	<script>
      alert('Account successfully created.');
      window.location.href='login.php';
    </script>
	
	<?php   
	
    } else {  
    echo "Failure!";  
    }  
  
    } else {  
   ?>
	<script>
      alert('All fields are required!');
      window.location.href='login1.php';
    </script>
	
	<?php   
    }  
  
//} else {  
//    echo "All fields are required!";  
//}  
}  
?>  
<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-33">
						Registration Form
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid eid is required">
						<input class="input100" type="text" name="eid" placeholder="Enter EmpID" required="required">
						
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Valid username is required">
						<input class="input100" type="text" name="username" placeholder="Enter Username" required="required">
						
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password is required">
						<input class="input100" type="password" name="password" placeholder="Enter Password" required="required">
						
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required">
						<input class="input100" type="text" name="email" placeholder="Enter email" required="required">
						
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Valid phone is required">
						<input class="input100" type="text" name="phone" placeholder="Enter Phone" required="required">
						
					</div>

					<div class="container-login100-form-btn m-t-20">
						<button class="login100-form-btn" name="submit" >
							Register
						</button>
						<br/><br/><br/>
						<a href="login.php" class="login100-form-btn">Cancel</a>
					</div>

					
				</form>
			</div>
		</div>
	</div>

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>