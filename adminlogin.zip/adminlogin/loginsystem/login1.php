<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body onload="noBack();"onpageshow="if (event.persisted) noBack();" onunload="">
<?php
  //require('db.php');
  session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['email']))
    {
        $email = $_POST['email'];
        $password = md5($_POST['password']);

        $email = stripslashes($email);
        $email = mysql_real_escape_string($email);

        $password = stripslashes($password);
        $password = mysql_real_escape_string($password);

        //Checking is user existing in the database or not
       $query = "SELECT * FROM `user` WHERE email='$email' and password='$password'";
	   
        $result = mysql_query($query) or die(mysql_error());
        $rows = mysql_num_rows($result);

        if($rows==1)
        {
          $_SESSION['email'] = $email;
		  $_SESSION['password'] = $password;
		  //echo $_SESSION['eid'];exit;
			header("Location: send.php");
			exit;
        }
       else {  
    ?>
    <script>
      alert('Invalid Details.');
      window.location.href='login.php';
    </script>
    <?php 
    }  
	   
    }
else
{
?>
<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-33">
						<img src="logo.png" alt="Hero Imgs" width="100" height="100"><br/>Account Login
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required">
						<input class="input100" type="text" name="email" placeholder="Email ID" required="required">
						
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password is required">
						<input class="input100" type="password" name="password" placeholder="Password" required="required">
						
					</div>

					<div class="container-login100-form-btn m-t-20">
						<button class="login100-form-btn" name="submit">
							Sign in
						</button>
					</div>
					<div class="text-center">
						<span class="txt1">
							Create an account?
						</span>

						<a href="register.php" class="txt2 hov1">
							Sign up
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

<?php 
} ?>

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
<SCRIPT type="text/javascript">
 
	window.history.forward();
	
	function noBack() { window.history.forward(); }
</SCRIPT>
</body>
</html>