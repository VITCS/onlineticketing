<?php
session_start();
if (strlen($_SESSION['eid']==0)) {
  header('location:logout.php');
  } else{
	
?><!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Welcome </title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/heroic-features.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Welcome !</a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#"><?php echo $_SESSION['name'];?></a>
                    </li>
                    <li>
                        <a href="logout.php">Logout</a>
                    </li>
                  
                </ul>
            </div>
        </div>
    </nav>
	<h3 align="center">Employee Timesheet Report</h3>
	<div class="panel">
	<form action="" method="post" enctype="multipart/form-data">

	



	<table style="width:50%" align="center" border=1px solid black; border-collapse: collapse;>
  <tr>
    <th>Employee ID:</th>
    <td> <?php echo $_SESSION['eid'];?></td>
  </tr><tr>  
    <th>Employee Name:</th>
	<td><?php echo $_SESSION['name'];?></td>
    </tr>
     
</table>
</form>
</div>
    <!--<div class="container">
        <header class="jumbotron hero-spacer">
            <!--<h4>Employee Timesheet Report</h4>
            <div class="col-md-10 col-md-offset-1">
                                        <div class="panel">
                                            <div class="panel-heading">
                                                <div class="panel-title">
                                                    <h3 align="center">Employee Timesheet Report</h3>
                                                    <br />
													<form action="" method="post" enctype="multipart/form-data">

	


</form>

</div>
</div>
</div>
</div>-->


			<!--<a  href="logout.php" class="btn btn-primary btn-large">Logout </a>
			<a  href="logout.php" class="btn btn-primary btn-large">Logout </a>-->
            </p>
        </header>

        <hr>


      


        </div>

        <hr>


    </div>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>
<?php } ?>